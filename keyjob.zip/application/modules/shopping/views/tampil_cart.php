
      <!-- /.col-lg-3 -->

      <div class="col-lg-9">
        <form action="<?php echo base_url()?>shopping/ubah_cart" method="post" name="frmShopping" id="frmShopping" class="formhorizontal" enctype="multipart/form-data">
		
		<?php if ($cart = $this->cart->contents()){ ?>
			<table class="table">
				<tr id= "main_heading">
					<td width="2%">No</td>
					<td width="10%">Gambar</td>
					<td width="33%">Item</td>
					<td width="17%">Harga</td>
					<td width="8%">Qty</td>
					<td width="20%">Jumlah</td>
					<td width="10%">Hapus</td>
				</tr>
		
		<?php
	// Create form and send all values in "shopping/update_cart" function.
			$grand_total = 0; 
			$i = 1; 

			foreach ($cart as $item): 
			$grand_total = $grand_total + $item['subtotal']; 
			?>

				<input type="hidden" name="cart[<?php echo $item['id'];?>][id]" value="<?php echo $item['id'];?>" />
				<input type="hidden" name="cart[<?php echo $item['id'];?>][rowid]" value="<?php echo $item['rowid'];?>" />
				<input type="hidden" name="cart[<?php echo $item['id'];?>][name]" value="<?php echo $item['name'];?>" />
				<input type="hidden" name="cart[<?php echo $item['id'];?>][price]" value="<?php echo $item['price'];?>" />
				<input type="hidden" name="cart[<?php echo $item['id'];?>][gambar]" value="<?php echo $item['gambar'];?>" />
				<input type="hidden" name="cart[<?php echo $item['id'];?>][qty]" value="<?php echo $item['qty'];?>" />

				<tr>
					<td><?php echo $i++; ?></td>
					<td>
						<img class="card-img-top" src="<?php echo base_url() .'images/'.$item['gambar']; ?>"/>
					</td>
					<td>
						<?php echo $item['name']; ?>
					</td>
					<td>
						<?php echo number_format($item['price'], 0,",","."); ?>
					</td>
					<td>
						<input type="text" class="form-control input-sm" name="cart[<?php echo $item['id'];?>][qty]" value="<?php echo $item['qty'];?>" />
					</td>
					<td>
						<?php echo number_format($item['subtotal'], 0,",",".")?>
					</td>
					<td>
						<a href="<?php echo base_url()?>shopping/hapus/<?php echo $item['rowid'];?>" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-remove"></i>
						</a>
					</td>
					<?php 
						endforeach; 
					?>
				</tr>

				<tr>
					<td colspan="3">
						<b>Order Total: Rp <?php echo number_format($grand_total, 0,",","."); ?></b>
					</td>
					<td colspan="4" align="right">
						<a data-toggle="modal" data-target="#myModal" class ='btn btn-sm btn-danger' rel="noopener noreferrer">Kosongkan Cart</a>
						<button class='btn btn-sm btn-success' type="submit">Update Cart</button>
						<a href="<?php echo base_url()?>shopping/check_out" class ='btn btn-sm btn-primary'>Check Out</a>
					</td>
				</tr>
			</table>

			<?php } 
				else { 
					echo "<h3>Keranjang Belanja masih kosong</h3>"; 
				} 
			?>
	</form>
	<!-- Modal Penilai -->
 	<div class="modal fade" id="myModal" role="dialog">
 		<div class="modal-dialog">
 		<!-- Modal content-->
 			<div class="modal-content bg-danger">
 				<form method="post" action="<?php echo base_url()?>shopping/hapus/all">
 					<div class="modal-header">
 						<h4 class="modal-title">Konfirmasi</h4>
 						<button type="button" class="close" datadismiss="modal" aria-label="Close">
 							<span aria-hidden="true">&times;</span>
 						</button>
 					</div>
 					<div class="modal-body"> 
 						<p>Anda yakin mau mengosongkan Shopping Cart?&hellip;</p>
 					</div>
 					<div class="modal-footer justify-content-between">
 						<button type="button" class="btn btn-outline-light" data-dismiss="modal">Tidak</button>
 						<button type="submit" class="btn btn-outline-light">Ya</button>
 					</div>
 				</form>
 			</div>
 		</div>
 	</div>

      </div>
      <!-- /.col-lg-9 -->

    </div>

  </div>
  <!-- /.container -->

